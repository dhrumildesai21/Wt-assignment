
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `FirstName` varchar(255) NOT NULL,
  `LastName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Country` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `pwd` varchar(8) NOT NULL,
  `gender`varchar(255)NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `student` (`id`, `FirstName`, `LastName`, `Email`, `Country`, `type`, `pwd`,`gender`) VALUES
(1, 'Dhrumil', 'desai', 'ddhrumil@gmail.com', 'India', 'student', '','male'),
(6, 'Aashu', 'shah', 'aashu10@gmail.com', 'canada', 'Student', '123','male'),
(7, 'varun', 'randive', 'varun10@gmail.com', 'India', 'Student', '','male'),
(8, 'caralina', 'sweetu', 'caru1@gmail.com', 'usa', 'faculty', '25d55ad2','female');

ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

