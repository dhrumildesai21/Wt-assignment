<?php 

require_once("connection.php");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Assignment 5</title>
		<link rel="stylesheet" type="text/css" href="stylingpage.css">
	</head>
<body>

	<video autoplay muted loop class="myVideo">
  	<source src="videoplayback.mp4" type="video/mp4">
  			Your browser does not support HTML5 video.
	</video>
   <div class="content">
	<h3 class="headings">task 5</h2>
	<h1 class="headings">wt project</h1>
	<div class="formdiv">
		<form  method="post">
			<table cellpadding="15px">
				<tr>
					<td>
						<label>FirstName: </label>
					</td>
					<td>
						<input type="text" id="fname" name="FirstName" data-placeholder="NAME" required><br>
					</td>
				</tr>
				<tr>
					<td>
						<label>LastName: </label>
					</td>
					<td>
						<input type="text" id="lname" name="LastName" required ><br>
					</td>
				</tr>
				<tr>
					<td>	
						<label>Email:</label>
					</td>
					<td>
						<input type="text" id="maill" name="Email" required><br>
					</td>
				</tr>
                <tr>
					<td>
						<label>Password: </label>
					</td>
					<td>
						<input type="Password" id="pwd" name="pwd" data-placeholder="PASSWORD" required><br>
					</td>
				</tr>
				<tr>
					<td>
<label>Male:</label>
  						<input type="radio" id="gen" name="gender" value="male" required>	
  										</td>
<label>Female:</label>
  						<input type="radio" id="gen" name="gender" value="female" required>
				</tr>
				<tr>
					<td>
						<label>Country: </label>
					</td>
					<td>
					   <select id="country" name="Country" required>
					   <option value="India">india</option>
					   <option value="canada">canada</option>
					   <option value="usa">usa</option>
					   <option value="aus">aus</option>
					   <option value="england">england</option>
					   </select>
					</td>
				</tr>

				<tr>
					<td>	
						<label>I am a : </label>
					</td>
					<td>
  						<input type="radio" id="Student" name="type" value="Student">
						<label for="Student">Student</label><br>
						<input type="radio" id="Faculty" name="type" value="Faculty">
						<label for="Faculty">Faculty</label><br>
						
					</td>
				</tr>
				<tr>
					<td colspan="2">
						<input class="btn" type="submit" name="submit" value="Register">
					</td>		
				</tr>
			</table>

		</form>	
	</div>
</div>
</body>
</html>
<?php
	if ($_SERVER["REQUEST_METHOD"]=="POST")
	{
		if (isset($_POST["FirstName"]) && isset($_POST["LastName"]) && isset($_POST["Email"]) && isset($_POST["Country"]) && isset($_POST["type"]) && isset($_POST["pwd"]) && isset($_POST["gender"]))
		{
			$fname=$_POST["FirstName"];
			$lname=$_POST["LastName"];
			$email=$_POST["Email"];
			$pwd=$_POST["pwd"];
			$country=$_POST["Country"];
			$work=$_POST["type"];
			$gen=$_POST["gender"];

			if($fname!=' ' && $lname!=' ' && $email!=' ' && $country!=' ' && $work!=' ' && $pwd && $gen!=' ')
			{
				$sql = "insert into student(FirstName,LastName,Email,Country,type,pwd)values('".$fname."','".$lname."','".$email."','".$country."','".$work."','".md5($pwd)."','".$gen."')";
				$result=mysqli_query($conn,$sql);
				print_r($result);
				die;
				if($result)
				{
					echo "<script>alert('Record inserted');document.location='assign5.php'</script>";
				}
			}
		}
		else
		{
			echo"value not set";
		}
	}
?>